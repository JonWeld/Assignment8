package com.example.dd_dice_roller;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;

import java.util.*;

public class D20Activity extends Activity {

    private Button rollAgainButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d20);

        // get references to the UI elements
        TextView resultText = findViewById(R.id.resultText);
        rollAgainButton = findViewById(R.id.rollButton);

        // set the number of sides for the D20 die
        int sides = 20;

        // generate a random number between 1 and 20
        int result = new Random().nextInt(sides) + 1;

        // display the result on the result layout for D20 die
        resultText.setText(String.valueOf(result));

        // set the onClickListener for the rollAgainButton to restart the activity
        rollAgainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recreate();
            }
        });
    }
    // allows you to press a button to get back to the main menu
    public void onBackButtonClicked(View view) {
        finish();
    }
}

