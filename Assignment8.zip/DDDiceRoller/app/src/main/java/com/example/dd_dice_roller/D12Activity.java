package com.example.dd_dice_roller;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;

import java.util.*;

public class D12Activity extends Activity {

    private Button rollAgainButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d12);

        // get references to the UI elements
        TextView resultText = findViewById(R.id.resultText);
        rollAgainButton = findViewById(R.id.rollButton);

        // set the number of sides for the D12 die
        int sides = 12;

        // generate a random number between 1 and 12
        int result = new Random().nextInt(sides) + 1;

        // display the result on the result layout for D12 die
        resultText.setText(String.valueOf(result));

        // set the onClickListener for the rollAgainButton to restart the activity
        rollAgainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recreate();
            }
        });
    }
    // allows you to press a button to get back to the main menu
    public void onBackButtonClicked(View view) {
        finish();
    }
}

